package com.tuuam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TuuamBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
